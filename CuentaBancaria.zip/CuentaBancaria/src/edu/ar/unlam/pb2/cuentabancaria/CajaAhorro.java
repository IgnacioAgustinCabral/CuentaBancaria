package edu.ar.unlam.pb2.cuentabancaria;

public class CajaAhorro {
	private Double saldo = 0.0;

	public CajaAhorro(Double saldo){
		this.saldo  = saldo;
	}

	public Double getSaldo() {
		// TODO Auto-generated method stub
		return this.saldo;
	}
}
