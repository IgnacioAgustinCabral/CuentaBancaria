package edu.ar.unlam.pb2.cuentabancaria;

public class CuentaBancaria {
	
}
